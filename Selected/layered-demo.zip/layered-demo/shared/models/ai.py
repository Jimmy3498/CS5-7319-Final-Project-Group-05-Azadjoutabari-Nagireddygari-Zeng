from dataclasses import dataclass, field

from .common import SecretInput
from .world import CampaignContent, TextRecord, WorldDefinition


@dataclass(frozen=True)
class ProviderProfile:
    id: str
    owner_id: str
    name: str
    endpoint: str
    model: str
    protocol: str  # One of the explicitly supported HTTP adapters.
    configuration_revision: int
    credential_present: bool


@dataclass(frozen=True)
class ProviderCapture:
    """Private per-operation capture. Never serialize into a public receipt/event."""

    profile: ProviderProfile
    credential: SecretInput = field(repr=False)


@dataclass(frozen=True)
class DirectorContext:
    campaign_id: str
    session_id: str
    revision: int
    world: WorldDefinition
    player_input: str
    player_character_id: str = ""
    flag_values: tuple[tuple[str, bool], ...] = ()
    disclosed_ids: tuple[str, ...] = ()
    setup: tuple[TextRecord, ...] = ()
    accepted_history: tuple[str, ...] = ()


@dataclass(frozen=True)
class VisibleFact:
    id: str
    text: str
    stance: str


@dataclass(frozen=True)
class PlayerView:
    """Built by KnowledgePolicy; renderer accepts this type, never DirectorContext."""

    session_id: str
    revision: int
    player_character_id: str
    facts: tuple[VisibleFact, ...]
    accepted_history: tuple[str, ...]
    player_input: str


@dataclass(frozen=True)
class ProviderMessage:
    role: str
    content: str = field(repr=False)


@dataclass(frozen=True)
class ProviderResponse:
    content: str = field(repr=False)
    input_tokens: int | None = None
    output_tokens: int | None = None
    finish_reason: str | None = None


@dataclass(frozen=True)
class EditorCompletion:
    """Strict provider response for a reviewed editor proposal."""

    candidate: CampaignContent
    summary: str
